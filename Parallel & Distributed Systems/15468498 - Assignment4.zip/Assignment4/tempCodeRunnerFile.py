g = open("HTML.html", "w")
    g.write(f"{soup}")
    g.close